-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 30-01-2020 a las 16:09:48
-- Versión del servidor: 8.0.18
-- Versión de PHP: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `id12157247_changerequest`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pro`
--

CREATE TABLE `pro` (
  `nombre` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `med` varchar(70) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `color` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `modelo` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `serie` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cali` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `vol` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `tipo` varchar(60) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `otro` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `id` int(11) NOT NULL,
  `ref` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `cat` varchar(70) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `pro`
--

INSERT INTO `pro` (`nombre`, `med`, `color`, `modelo`, `serie`, `cali`, `vol`, `tipo`, `otro`, `id`, `ref`, `cat`) VALUES
('jesus', '1m', 'rojo', 'n/a', 'vf45', 'n/a', 'n/a', 'n/a', 'n/a', 1, '', ''),
('Luis', 'PZ', 'Negro', 'P117', 'JSDU6', '5\"', '500', 'fisico', 'Concexion a mangera de cobre a PVC ', 2, '', ''),
('Luis', 'Pzs', 'Negro', 'Jdye56', 'Nekf56', '56\"', '599', 'Prueba', 'Con acceso de cobre para agua caliente y CPVC para unión de manguera ', 3, '', ''),
('', '34', '', 'SDF', 'SDF', 'SDF', 'SDF', 'SDF', 'SDFSF', 4, '', ''),
('Jorge valdes', '100 mts', 'Negro', 'Thw', 'Xxx', '6', '75 amp', 'Xx', 'Alta temperTura', 5, '', ''),
('Gearardo medina', '3/4\"', 'Blanco', '', '', '', '', 'O+', '', 6, '', ''),
('Cinta teflón', '3/4\"', 'Blanco', '', '', '', '', 'O+', '', 7, '', ''),
('PAULINA ALEXA CONTRERAS VALDES', 'METROS', 'NEGRO', 'PAU-1993', 'PACV', '50', '40 AMP', 'CABLE', 'DE 4 HILOS /COBRE', 8, '', ''),
('Bomba sumergible para drenaje', '1.5 HP', 'N/A', 'Pedrollo', 'Dm 30-N-2', '', '220 volts, 3 fases', 'Sumergible', 'Agua sucia, flotador basculante', 9, '', ''),
('Abrazadera 1\"', 'Pieza', 'N/A', '1\" ', 'N/A', 'N/A', 'N/A', 'Sin fin', '', 10, '', ''),
('Pintura', 'Litros', 'Azul', 'N/A', 'N/A', 'N/A', 'N/A', 'Vinilica', 'Pintura de aceite, de secado rápido MCA Comex.', 11, '', ''),
('Tubería flexible de cobre(tubo conduit)', '3/8', 'Gris', 'Nfx0001', '', '', '', 'Flexible', 'Marca Anclo ', 12, '', ''),
('prueba', '33 m', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 14, '', ''),
('Espiroquetas cuántica', 'Pieza', 'Rojo', 'General electric', '', '-', '10000 V', 'Imaginario', 'Desconocidas', 15, '', ''),
('prueba', 'prueba', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 24, 'prueba', 'Elevadores'),
('prueba', 'prueba', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 'n/a', 25, 'prueba', 'Elevadores'),
('Adrián Pérez', 'Galón', '', '', '', '', '', 'Policlay', '', 26, 'Desincrustante AC-10', 'consumible'),
('Guillermo Nova González', 'Pza', '', 'Linmex', '', '', '', '', '275 gramos ', 27, 'Cartucho gas butano ', 'consumible'),
('Guillermo Nova González', 'Pza', '', '', '', '', '', 'GAS BUTANO', '', 28, 'Boquilla linmex', 'Herramienta'),
('Guillermo Nova González', 'Metro', '', '', '', '', '', '', 'AGUA', 29, 'SOLDADURA OMEGA 50/50', ''),
('Guillermo Nova González', 'PZA', '', '616293', '', '', '', 'CENTRIFUGA', '', 30, 'BOMBA 1 HP CENTRIFUGA PARA AGUA ', ''),
('Guillermo Nova González', 'PZA', '', '', '', '', '', '', 'COBRE', 31, 'CONECTOR COBRE ROSCA EXTERIOR 1\"', ''),
('Guillermo Nova González', 'PZA', '', '', '', '', '', '', '', 32, 'CINTA TEFLÓN 1/2 ', ''),
('Jorge valdes', '100 MTS', 'NEGRO', 'THW-LS/THHW- LS', '13.3mm2', '6', '600V', 'ANTIFLAMA', '75°C/90°C', 33, 'CABLE MONOPOLAR', ''),
('Jorge valdes', '100 MTS', 'NEGRO', 'THW-LS/THHW- LS', '13.3mm2', '6', '600V', 'ANTIFLAMA', '75°C/90°C', 34, 'CABLE MONOPOLAR', 'Insumos'),
('Jorge valdes', '100 MTS', 'VERDE', 'THW-LS/THHW- LS', '8.3mm2', '8', '600V', 'ANTIFLAMA', '75°C/90°C', 35, 'CABLE MONOPOLAR', 'Insumos'),
('Jorge valdes', '100 MTS', 'Negro', 'THW-LS/THHW- LS', '5.2mm2', '10', '600V', 'ANTIFLAMA', '75°C/90°C', 36, 'CABLE MONOPOLAR', 'Insumos'),
('Jorge valdes', '1pza', '', '20-KPD-404', 'CA-2', '', '65', 'industrial', '220-127 V.  CON CONTROL Y TABLERO DE TRANSFERENCIA AUTOMATICA Y CASETA ACUSTICA- CA2', 37, 'PLANTA DE EMERGENCIA DE 20 KW/25KVA-TRIFASICA ', 'Insumos'),
('Jorge valdes', '1pza', '', '20-KPD-404', 'CA-2', '', '65', 'industrial', '220-127 V.  CON CONTROL Y TABLERO DE TRANSFERENCIA AUTOMATICA Y CASETA ACUSTICA- CA2', 38, 'PLANTA DE EMERGENCIA DE 20 KW/25KVA-TRIFASICA ', 'Insumos'),
('Jorge valdes', '1pza/3mts', '', 'PARED DELGADA', '', '38 mm', '', 'GALVANIZADO', '', 39, 'TUBO CONDUIT 38 mm', 'consumible'),
('Jorge valdes', 'Pieza', '', 'INYECCION DE ALUMINIO', '3', '38mm-(1.1/2)', '', 'LB57', '', 40, 'CAJA REGISTRO CONDULET LB', 'consumible'),
('', '', '', '', '', '', '', '', '', 41, '', ''),
('Jorge valdes', 'PIEZA', '', 'TIPO AMERICANO', '', '38mm (1.1/2)', '', 'ACERO', '', 42, 'CONECTOR CONDUIT  TIPO AMERICANO', 'consumible'),
('Guillermo Nova González', 'PZA', '', '', '', '', '', '', '', 43, 'CINTA TEFLÓN 1/2 ', ''),
('prueba', 'n/a', 'n/a', 'n/a', 'n/a', '', '', '', '', 44, 'prueba', 'Equipo'),
('Jorge Valdes', '', '', '', '', '', '103', 'Industrial', 'hasferin', 45, 'Planta de emegencia de 20 kw/25kva trisafica 220-127v con control y trablerode transferencia', 'Equipo'),
('Jorge Valdes', '', '', '', '', '', '103', 'INDUSTRIAL', 'HASFRATIN', 46, 'PLANTA DE EMERGENCIA DE 20 KW/25KVA TIRASASICA 22-127V CON CONTROL Y TABLERO DE TRANSFERENCIA AUTOMATICA', 'Equipo'),
('Jorge valdes', 'PIEZA', '', 'TIPO AMERICANO', '', '38mm', '', 'Acero', '', 47, 'COPLE CONDUIT P/D', 'Insumos'),
('Jorge valdes', 'PIEZA', '', '', '', '38mm', '', 'ACERO', '', 48, 'CODO CONDUIT 90°', 'Insumos'),
('Jorge valdes', 'PIEZA', '', 'ABRAZADERA OMEGA', '', '38mm', '', 'ACERO GALVANIZADO', '', 49, 'ABRAZADERA OMEGA', 'Suministro'),
('Jorge valdes', 'PIEZA', 'GRIS', 'TC-2872', '', '1/4\"', '', 'TOOLCRAFT', '', 50, 'TAQUETE EXPANSIVO DE PLASTICO', 'Insumos'),
('Jorge valdes', 'PIEZA', '', 'CABEZA LAMINADA-COMBINADA', '', '8*1-1/2\"', '', 'GALVANIZADA', '', 51, 'PIJA', ''),
('Jorge valdes', 'MTS', 'Gris', '', '', '1.1/2\"', '', 'GALVANIZADO RECUBIERTO DE PVC', 'TUBO LICUATITE', 52, 'TUBO FLEXIBLE ENGARGOLADO RECUBIERTO DE PVC', 'Suministro'),
('Jorge valdes', 'PIEZA', '', '', '', '1.1/2\"', '', 'RECTO', 'CONECTOR PARA TUBO LICUATITE DE 38mm', 53, 'CONECTOR RECTO', 'Suministro'),
('Jorge valdes', 'PIEZA', 'GRIS', 'QO30 -3F-4H', '', '', '100A', 'PARA EMPOTRAR', '', 54, 'TABLERO SQUARED', 'Suministro'),
('Jorge valdes', 'PIEZA', 'Negro', 'SQUARE D', '127-240V 10KV', '', '20A', 'UN POLO', '', 55, 'PASTILLA TERMOMAGNETICA ', 'Suministro'),
('', '', '', '', '', '', '', '', '', 56, '', ''),
('', '', '', '', '', '', '', '', '', 57, '', ''),
('', '', '', '', '', '', '', '', '', 58, '', ''),
('', '', '', '', '', '', '', '', '', 59, '', ''),
('', '', '', '', '', '', '', '', '', 60, '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `solicitudes`
--

CREATE TABLE `solicitudes` (
  `fecha` date NOT NULL,
  `autor` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `descr` text NOT NULL,
  `impacto` text NOT NULL,
  `justif` text NOT NULL,
  `proceso` varchar(50) NOT NULL,
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `solicitudes`
--

INSERT INTO `solicitudes` (`fecha`, `autor`, `email`, `descr`, `impacto`, `justif`, `proceso`, `id`) VALUES
('2020-01-07', 'Alfredo', 'jesusreyesvaldes_alfredo@outlook.com', 'Bombilla', 'Centro de carga', 'necesidad del cliente', 'solicitado', 1),
('2020-01-08', 'Miguel', 'miguel.martinez.bacros@gmail.com', 'Vistas', 'Reportes', 'Reportes', 'Solicitado ', 2),
('2020-01-08', 'Miguel', 'miguel.martinez.bacros@gmail.com', 'Vistas', 'Reportes', 'Reportes', 'Solicitado ', 3),
('2020-01-27', 'PAULINA CONTRERAS', 'paulina.contreras@bacrocorp.com', 'PRUEBA ', 'CAPACITACION', 'APRENDER A USAR LA HERRAMIENTA', 'SOLICITADO', 10),
('2020-01-27', 'GERARDO VALDEZ CONTRERAS ', 'gerardomedi.41@gmail.com', 'HOLA COMPAÑEROS CON LA NOVEDAD QUE NO SE NADA DE EL PROGRAMA QUIEN ME APOYA CON ASESORIAS FUERA DE TRABAJO ', 'IMPACTA POR QUE ME REGAÑAN ', 'YO UTILIZABA PURA MAQUINA DE ESCRIBIR ', '', 11),
('2020-01-27', 'JORGE VALDES', 'jorge.valdes@bacrocorp.com', 'PRUEBA', 'CAPACITACION', 'APRENDER A USAR LA HERRAMIENTA', 'SOLICITADO', 12),
('2020-01-27', 'Adrian', 'adrian.perez@bacrocorp.com', 'No me sirve el botón de imprimir', 'No puedo escribir', 'No puedo trabajar', 'Mal estado', 13),
('2020-01-27', 'Fernando ', 'Fernando.gonzalez@bacrocorp.com', 'Gary nesecito visitrack', 'No puedo ', 'Versión vieja ', 'Solicitafo', 14),
('2020-01-27', 'Guillermo Nova González', 'guillermo.nova@bacrocorp.com', 'Prueba', 'No se ', 'Eu', 'Solicitado', 15),
('2020-01-27', 'Miguel romero ', 'miguel.romero@bacrocorp.com', 'PRUEBA', 'CAPACITACIÓN ', 'HERRAMIENTA ', 'Solicitado', 16),
('2020-01-27', 'Valdez ', 'jose.valdez@bacrocorp.com', 'No se registra mi correo sin acento', 'Problemas de acceso', '', '', 17),
('2020-01-27', 'Vquero', 'jorge.valdes@bacrocorp', 'Hdhbdjdjd', 'Jdjdbhhd', 'Jdjdjjd', 'Fuera de servicio', 18),
('2020-01-27', 'Rodrigo Guadarrama', 'rodrigo.guadarrama@bacrocorp.com', 'No sé puede sincronizar mi teléfono con la impresora', '', '', 'Solicitado', 19),
('2020-01-27', 'ROGELIO NAVA', 'rogelio.nava@bacrocorp.com', 'No aparecen las rutinas', 'Retrasa el servicio de mantenimiento preventivo', 'No responde Gary las  dudas  en tiempo y forma del tema de visitrack', 'Solicitado', 20),
('2020-01-27', 'Leonardo', 'leonardo.martinez@bacrocorp.com', 'Prueba', 'Prueba', 'Funcionamiento del sistema', 'Proceso', 21),
('2020-01-27', 'Guillermo peña adame', 'penaag71@yahoo.com.mx', 'Reporte de impresora', 'Reportes', 'Retraso', 'Fuera', 22),
('2020-01-27', 'RICARDO ROSALES CAMACHO ', 'ricardo.rosales@bacrocorp.com', 'Prueba ', 'APRENDIZAJE', 'APRENDER', 'Solicitado', 23),
('2020-01-27', 'Efren Sanchex', 'efren.sanchez@bracrocorp.com', 'Están repetidos las claves de los equipos en visitrak', 'Prueba', 'Prueba ', 'Prueba', 24),
('2020-01-27', 'Gerardo Medina Ahumada', 'gerardo.medina@bacrocorp.com', 'Por todo me regañan', 'Tengo baja autoestima', 'Nadie m entiende ', 'Solicitado', 25),
('2020-01-27', '', '', '', '', '', '', 26),
('2020-01-27', '', '', '', '', '', '', 27),
('2020-01-27', '', '', '', '', '', '', 28),
('2020-01-27', 'Carmen', 'carmen.rojas@bacrocorp.com', 'Instructivo de uso del visitrak en el móvil actualizado y darme clave de usuario al visitrak', 'Tiempos de respuesta y organización', 'La retroalimentación en tiempo ahorra retrasos en reporte de servicio', 'Solicitado', 29),
('2020-01-27', 'Carmen', 'carmen.rojas@bacrocorp.com', 'Instructivo de uso del visitrak en el móvil actualizado y darme clave de usuario al visitrak', 'Tiempos de respuesta y organización', 'La retroalimentación en tiempo ahorra retrasos en reporte de servicio', 'Solicitado', 30),
('2020-01-27', '', '', '', '', '', '', 35),
('2020-01-27', '', '', '', '', '', '', 36),
('2020-01-27', '', '', '', '', '', '', 37),
('2020-01-28', 'Guillermo peña adame', 'penaag71@yahoo.com.mx', 'Planta de emergencia en subdireccion de logistica cambiar selector de 3 posiciones MAN-0-AUTO marca telemecaniqueZB2-BE101 ', 'Equipo sin arranque manual', 'Para su funcionamiento al 100%.', 'Sin funcionar manual', 38),
('2020-01-28', 'Claudia Sosa', 'claudia.sosa@bacrocorp.com', 'Añadir las encuestas de NOM 035', 'Auditoría de la norma', 'Auditoría de la NOM', 'Solicitado', 39),
('2020-01-30', 'pruebaguero', 'pruebasbac@outlook.com', 'bacro', 'bacro', 'bacro', 'bacro', 40),
('2020-01-30', 'pruebaguero', 'pruebasbac@outlook.com', 'bacro', 'bacro', 'bacro', 'bacro', 41),
('2020-01-30', 'pruebaguero', 'pruebasbac@outlook.com', 'bacro', 'bacro', 'bacro', 'bacro', 42),
('2020-01-30', 'pruebaguero', 'pruebasbac@outlook.com', 'bacro', 'bacro', 'bacro', 'bacro', 43),
('2020-01-30', 'pruebaguero', 'pruebasbac@outlook.com', 'bacro', 'bacro', 'bacro', 'bacro', 44),
('2020-01-30', 'pruebaguero', 'pruebasbac@outlook.com', 'bacro', 'bacro', 'bacro', 'bacro', 45),
('2020-01-30', 'pruebaguero', 'pruebasbac@outlook.com', 'bacro', 'bacro', 'bacro', 'bacro', 46),
('2020-01-30', '', '', '', '', '', '', 47),
('2020-01-30', '', '', '', '', '', '', 48),
('2020-01-30', '', '', '', '', '', '', 49),
('2020-01-30', '', '', '', '', '', '', 50),
('2020-01-30', '', '', '', '', '', '', 51);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pro`
--
ALTER TABLE `pro`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pro`
--
ALTER TABLE `pro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT de la tabla `solicitudes`
--
ALTER TABLE `solicitudes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
