<?php
	$servername = "localhost";
	$username = "bacro";
	$password = "";
	$dbname = "id12157247_changerequest";

	$ar = 0;

	/*$date = $_POST["date"];
	$author = $_POST["author"];
	$email = $_POST["email"];
	$desc = $_POST["desc"];
	$impacto = $_POST["impacto"];
	$justif = $_POST["justif"];*/

	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	// prepare and bind
	$stmt = $conn->prepare("INSERT INTO solicitudes (fecha, autor, email, descr, impacto, justif, proceso) VALUES (?, ?, ?, ?, ?, ?, ?)");
	$stmt->bind_param("sssssss", $date, $author, $email, $desc, $impacto, $justif, $proceso);
	// set parameters and execute
	$date = $_POST["date"];
	$author = $_POST["author"];
	$email = $_POST["email"];
	$desc = $_POST["desc"];
	$impacto = $_POST["impacto"];
	$justif = $_POST["justif"];
    $proceso = $_POST["proceso"];
    $id = $_POST["id"];
	$stmt->execute();

	$ar = $stmt->affected_rows;
	//printf("%d Row inserted.\n", $stmt->affected_rows);

	/* close statement and connection */
	$stmt->close();




	/*
	$sql = "SELECT * FROM solicitudes";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		// output data of each row
		while($row = $result->fetch_assoc()) {
			echo "id: " . $row["asd"]. " - Name: " . $row["author"]. " " . $row["email"]. "<br>";
		}
	}*/

	/*$sql = "INSERT INTO solicitudes (firstname, lastname, email)
	VALUES ('John', 'Doe', 'john@example.com')";

	if ($conn->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}*/

		
	

?>

<html>
	<head>
	<?php include 'partials/menu.php';?>
		<meta charset="UTF-8">

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

		<!-- Latest compiled JavaScript -->
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	  </head>

	<body>
	<br><br><br><br>
		<div class="container" style="background: #DDF7F2; border-radius: 0px 0px 10px 10px;">
		  <table width="100%">
			<tr>
			<center>  <td width="50%"><h1>Corporativo Bacros</h1></td></center>
			  <td width="50%">
				<p class="text-right">
				
				</p>
			  </td>
			</tr>
			<tr>
			  <td colspan="2"><p>Petición de Cambios al Sistema.</p></td>
			</tr>
		  </table>
		</div>


		<br/><br/>

		<div class="container" style="background: #EEF3FB; border-radius: 10px;">
			<br/>

			<div align="center">
				<?php
					if($ar>0){
						echo "<h1>Registro Exitoso</h1>";
					} else {
						echo "<h1>Registro Fallido, Vuelva a intentar</h1>";
					}
				?>
			</div>

			<div class="form-horizontal">
				<div class="form-group">
					<label class="control-label col-sm-2" for="date">Fecha:</label>
					<div class="col-sm-10">
						<?php echo $date; ?>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-2" for="date">Autor:</label>
					<div class="col-sm-10">
						<?php echo $author; ?><br>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-2" for="date">Email:</label>
					<div class="col-sm-10">
						<?php echo $email; ?><br>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-2" for="date">Descripción:</label>
					<div class="col-sm-10">
						<?php echo $desc; ?><br>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-2" for="date">Impacto:</label>
					<div class="col-sm-10">
						<?php echo $impacto; ?><br>
					</div>
				</div>

				<div class="form-group">
					<label class="control-label col-sm-2" for="date">Justificación:</label>
					<div class="col-sm-10">
						<?php echo $justif; ?><br>
					</div>
				</div>
				
					<div class="form-group">
					<label class="control-label col-sm-2" for="date">Estado:</label>
					<div class="col-sm-10">
						<?php echo $proceso; ?><br>
				
					
				
<!--ESTE BOTON DIRIGIRA A CONSULTAR LOS DATOS-->
<input type="button" onclick="location.href= 'consulta.php'" value="Consulta" name="boton" />
			</div>

		</div>

	</body>
</html>

