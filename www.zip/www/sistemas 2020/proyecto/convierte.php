<?php
    
    header("Content-Type:application/xls");
	header("Content-Disposition: attachment; filename=nombre_archivo.xls");
   require_once('conexion.php');
    
	$conn=new Conexion();
	$link = $conn->conectarse();

	$query="SELECT * FROM pro";
	$result=mysqli_query($link, $query);
?>

<table border="1">
	<tr style="background-color:red;">
		<th>Nombre,Medida,Color,Modelo,No. Serie,Calibre,Volt's o AMP,Tipo, Otras especificaciones/</th>
		
	</tr>
	<?php
		while ($row=mysqli_fetch_assoc($result)) {
			?>
				<tr>
					<td><?php echo $row['nombre']; echo ','; echo $row['med'];echo ','; echo $row['color']; echo ','; echo $row['modelo']; echo ','; echo $row['serie']; echo ','; echo $row['cali'];  echo ',';echo $row['vol'];echo ','; echo $row['tipo']; echo ',';echo $row['otro']; ?></td>
					
				</tr>	

			<?php
		}

	?>
</table>