<?php
$carpeta = "files/";
opendir($carpeta);
$desino = $carpeta.$_FILES['foto']['name'];
copy($_FILES ['foto']['tmp_name'],$desino);
echo "ARCHIVO EXITOSO";
$nombre=$_FILES['foto']['name'];
echo "<img scr=\"files/$nombre\">";

?>
