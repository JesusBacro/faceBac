<!-- Pie de página -->
<footer class="page-footer font-small blue">

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3"> 

       B A C R O C O R P
    </div>
    <!-- Copyright -->

</footer>
<!-- Footer -->

</div>

<!-- Fin de la página HTML -->
</body>
</html>
