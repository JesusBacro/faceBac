<!--//con la declaracion "PHP include_once" podemos optimizar el uso del encabezado apra todas las paginas php-->

<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

        <!-- establecemos el título de la página a traves de un parametro si no se encuentra defino se utiliza el texto -->
        <title><?php echo isset($page_title) ? strip_tags($page_title) : "BACROCORP"; ?></title>

        <!-- Bootstrap CSS -->
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" media="screen" />
        <link href="estilos.css" rel="stylesheet" media="screen">

    </head>
    <body>
        <div class="contenedor">
        <div class="container" style="background: #DDF7F2; border-radius: 0px 0px 10px 10px;">
      <table width="100%">
        <tr>
          <td width="50%"><h1>Corporativo Bacros</h1></td>
          <td width="50%">
            <p class="text-right">
              <img src="https://s3.amazonaws.com/logocompanies/CEA5A9A9-5EF0-46CA-AD7A-314B45507566.JPG" width="180" alt="Responsive image" style="border-radius: 10px;">
            </p>
          </td>
        </tr>
        <tr>
          <td colspan="2"><p></p></td>
        </tr>
      </table>
    </div>
    <div class="container" style="background: #EEF3FB; border-radius: 10px;">
      <br/>
        <div class="page-header">
             <h1> <center> <img src="./recursos/BACRO.png" class="img-rounded"  width="500" height="200"></center></h1>
        </div>
        <!-- incluimos la barra de navegacion -->
        <?php include_once 'navigation.php'; ?>

        <!-- contenedor -->
        <div class="container">

            <?php
            // si el título de la página dado es 'Iniciar sesión', no muestre el título
            if ($page_title == "Registro") {
                ?>
                <div class='col-md-12'>
                    <div class="page-header">
                        <h1><?php echo isset($page_title) ? $page_title : ""; ?></h1>
                    </div>
                </div>
                <?php
            }
            ?>
