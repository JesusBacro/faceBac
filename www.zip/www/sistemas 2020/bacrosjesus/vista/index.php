<?php include 'partials/head.php';?>
<?php include 'partials/menu.php';?>

<div class="container">

	<div class="starter-template">
		<br>
		<br>
		<br>
		<div class="jumbotron">
			<div class="container">
				<center><h1>B A C R O   C O R P</h1>
				<p>Aquí puedes realizar tus formatos de alta de productos & Cambios de peticiones al sistema</p></center>
				<p>
					<a href="login.php" class="btn btn-primary btn-lg">Login</a>
				</p>
			</div>
		</div>
	</div>

</div><!-- /.container -->

<?php include 'partials/footer.php';?>