<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" href="estilos.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
<html lang="en">
<head>
    <title>BACROCORP</title>
    <link rel="stylesheet" href="../themes/default/default.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="../themes/light/light.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="../themes/dark/dark.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="../themes/bar/bar.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="../nivo-slider.css" type="text/css" media="screen" />
    <link rel="stylesheet" href="stilo.css" type="text/css" media="screen" />
</head>
<body>
     <input type="checkbox" id="check">
    <label for="check">
      <i class="fas fa-bars" id="btn"></i>
      <i class="fas fa-times" id="cancel"></i>
    </label>
      <!--doy inicio al menu -->
     <div class="sidebar">
    <header>B A C R O C O R P</header>
  <ul>
<li><a href="view/admin/index.php"><i class="fas fa-qrcode"></i>Regresar</a></li>
    
    <li><a href="../../controller/cerrarSesion.php"><i class="far fa-envelope"></i>Cerrar Sessión</a></li>
  </ul>
</div>
<section>
    <div id="wrapper">
  

        <div class="slider-wrapper theme-default">
            <div id="slider" class="nivoSlider">
                <img src="img/1.jpeg"  alt="" />
               <img src="img/2.jpeg"  alt="" /></a>
                <img src="img/3.jpeg"  alt=""  />
                <img src="img/4.jpeg"  alt=""  />
            </div>
            <div id="htmlcaption" class="nivo-html-caption">
               
            </div>
        </div>

    </div></section>
    <script type="text/javascript" src="scripts/jquery-1.9.0.min.js"></script>
    <script type="text/javascript" src="../jquery.nivo.slider.js"></script>
    <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>
</body>
</html>