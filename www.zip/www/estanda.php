<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
   
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>BACROCORP</title>
</head>
<body>
<body>
	<header>
		<nav class="navegacion">
			<ul class="menu">
				<li><a href="#">BIENVENIDO AL SISTEMA EN LA WEB</a>
					<ul class="submenu">
						<li><a href="contratos.php">Estandarización</a></li>
						<li><a href="video.php">Videos Tutoriales</a></li>
						<li><a href="#">Manual de Usuario</a></li>
					</ul>
				</li>
				<li><a href="/view/admin/index.php">Regresar</a>
			</ul>
		</nav>
	</header>
</body>
</body>
</html>